Rails.application.routes.draw do
  get '/', :controller => 'rpg', :action => 'index'

  post 'process/farm', :controller => 'rpg', :action => 'farm'

  post 'process/cave', :controller => 'rpg', :action => 'cave'

  post 'process/house', :controller => 'rpg', :action => 'house'

  post 'process/casino', :controller => 'rpg', :action => 'casino'

end
