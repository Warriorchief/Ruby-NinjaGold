class RpgController < ApplicationController
  def index
    # reset_session
    if !session[:gold]
      session[:gold]=0
    end
    if !session[:allmessages]
      session[:allmessages]=[]
    end
    render 'index.html.erb'
  end

  def farm
    farmup = rand(10..20)
    session[:gold]+=farmup
    farmmessage="Earned "+farmup.to_s+" gold from the farm!"
    session[:allmessages].push(farmmessage)
    redirect_to('/')
    return
  end

  def cave
    caveup= rand(5..10)
    session[:gold]+=caveup
    cavemessage="Earned "+caveup.to_s+" gold from the cave!"
    session[:allmessages].push(cavemessage)
    redirect_to('/')
    return
  end

  def house
    houseup = rand(2..5)
    session[:gold]+=houseup
    housemessage="Earned "+houseup.to_s+" gold from the house!"
    session[:allmessages].push(houseup)
    redirect_to('/')
    return
  end

  def casino
    casinoupdown = rand(-50..50)
    session[:gold]+=casinoupdown
    if casinoupdown<0
      casinomessage="."+" Entered a casino and lost "+casinoupdown.to_s+" gold....Ouch..."
    else
      casinomessage= "Entered a casino and earned "+casinoupdown.to_s+" gold!"
    end
    session[:allmessages].push(casinomessage)
    redirect_to('/')
    return
  end

end
